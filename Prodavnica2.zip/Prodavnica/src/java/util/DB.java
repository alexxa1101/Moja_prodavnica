package util;

public class DB {

    public static String user = "root";
    public static String pass = "";

    public static String protocol = "jdbc:mysql:";
    public static String ip = "localhost";
    public static String port = "3306";
    public static String dbName = "moja_prodavnica";

    public static String connectionString
            = protocol + "//" + ip + ":" + port + "/" + dbName;

}
