/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.dao;

import beans.Proizvod;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import util.DB;

/**
 *
 * @author Obuka
 */
public class ProizvodiDAO {
    public static  List<Proizvod> dohvatiProizvode(){
        List<Proizvod> proizvodi = new ArrayList<Proizvod> ();
        
         String sql = "select * from proizvod";
        
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance(); 
            Connection c = DriverManager.getConnection(
                        DB.connectionString, DB.user, DB.pass);
            PreparedStatement s = c.prepareStatement(sql); 
            ResultSet rs = s.executeQuery();
            
            while ( rs.next() ) {
                int idP = rs.getInt("idP");
                String naziv = rs.getString("naziv");
                int cena = rs.getInt("cena");
                String slika = rs.getString("slika");

                
                Proizvod proizvod = new Proizvod();
                proizvod.setCena(cena);
                proizvod.setIdP(idP);
                proizvod.setNaziv(naziv);
                proizvod.setSlika(slika);
                
                proizvodi.add(proizvod);
            }
            s.close();
            c.close();
            
            return proizvodi;
        } catch (SQLException ex) { 
            Logger.getLogger(ProizvodiDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProizvodiDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(ProizvodiDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(ProizvodiDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }
}
