/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import beans.Proizvod;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.ManagedBean;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import util.dao.ProizvodiDAO;

/**
 *
 * @author Obuka
 */

@ManagedBean
@SessionScoped
@Named(value = "proizvodiController")
public class ProizvodiController implements Serializable{
    List<Proizvod> proizvodi;

    public List<Proizvod> getProizvodi() {
        return proizvodi;
    }

    public void setProizvodi(List<Proizvod> proizvodi) {
        this.proizvodi = proizvodi;
    }

    public void init(){
        proizvodi = ProizvodiDAO.dohvatiProizvode();
    }
    
    List<Proizvod> kupljeniProizvodi = new ArrayList<Proizvod>();
    
    public String kupiProizvod(Proizvod p){
        kupljeniProizvodi.add(p);
        racun=racun+p.getCena();
        return "korpa";
    }

    public List<Proizvod> getKupljeniProizvodi() {
        return kupljeniProizvodi;
    }

    public void setKupljeniProizvodi(List<Proizvod> kupljeniProizvodi) {
        this.kupljeniProizvodi = kupljeniProizvodi;
    }
    
    public void ukloniProizvod(Proizvod p){
        kupljeniProizvodi.remove(p);
        racun=racun-p.getCena();
    }
    
    int racun = 0;

    public int getRacun() {
        return racun;
    }

    public void setRacun(int racun) {
        this.racun = racun;
    }
    
    

}
